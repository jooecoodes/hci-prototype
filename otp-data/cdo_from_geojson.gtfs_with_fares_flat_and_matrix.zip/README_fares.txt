GTFS Fares Injection (CDO PUJ)
==============================

This package adds:
  1) fare_attributes.txt — REGULAR flat fare for first 4 km (₱13.00), currency PHP, pay-on-board, no transfers
  2) fare_rules.txt — Applies the regular flat fare system-wide
  3) fare_matrix.csv — Reference distance-based fare matrix (1–50 km) for REGULAR and DISCOUNTED (20%) categories
     Source: Generic Fare Matrix for Traditional PUJ (with Provisional Fare Increase), Effective Oct 8, 2023.
     Computation (Add-on method):
       - Regular: First 4 km = ₱13.00; Succeeding = ₱1.80 per km
       - Discounted: First 4 km = ₱10.40; Succeeding = ₱1.44 per km
       - Round to nearest ₱0.25
     Note: Most GTFS consumers (including some OTP versions) do not fully support distance-based fares in GTFS-Static.
           If your router supports GTFS-Fares v2, consider implementing distance-based fare products using fare_leg_rules.
           Otherwise, this GTFS uses a flat fare so trip planning doesn't undercharge or misclassify discounts.

Files added by this process on 2025-09-24:
  - fare_attributes.txt
  - fare_rules.txt
  - fare_matrix.csv
  - README_fares.txt